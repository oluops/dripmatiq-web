DRIPMATIQ PRESS KIT
===================

One-liner:
  Dripmatiq is the private AI stylist that scans your closet, learns your taste,
  and builds daily outfits you'll actually wear — without uploading a single
  photo to a stranger's server.

Founder: Olu (solo, bootstrapped)
Press contact: press@dripmatiq.app
Website: https://dripmatiq.app

Brand colors:
  gold    #D4AF37
  surface #0E0E10
  ink     #F5F1E6

Typography:
  Display: Georgia
  Body:    system-ui

Files:
  icon-1024.png       — App icon, 1024x1024
  wordmark-light.svg  — Wordmark in cream
  wordmark-dark.svg   — Wordmark in gold
  screenshots/        — In-app screenshots (JPG)
